# SensusR 2.2.0
* Added support for asymmetric-key encryption.