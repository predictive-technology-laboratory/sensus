# SensusR 2.3.0
* Improved error checking on ingest.

# SensusR 2.2.0
* Added support for asymmetric-key encryption.